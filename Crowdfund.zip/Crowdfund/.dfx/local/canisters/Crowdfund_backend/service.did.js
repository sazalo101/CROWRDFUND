export const idlFactory = ({ IDL }) => {
  return IDL.Service({
    'contribute' : IDL.Func([IDL.Nat], [IDL.Text], []),
    'getTotalContributions' : IDL.Func([], [IDL.Nat], ['query']),
  });
};
export const init = ({ IDL }) => { return []; };
